import requests
from bs4 import BeautifulSoup
import json
import csv

# Fetch data from a website using web scraping
def fetch_data(url):
    response = requests.get(url)
    if response.status_code == 200:
        return response.content
    else:
        return None

# Store the fetched data in a JSON file
def store_data_json(data, file_path):
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)

# Store the fetched data in a CSV file
def store_data_csv(data, file_path):
    with open(file_path, 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerows(data)

# Extract relevant information from a news website
def extract_news_data(parsed_data, base_url):
    articles = parsed_data.find_all('div',class_='uwU81')
    extracted_data = []

    for article in articles:
        heading_element = article.find('div',class_='fHv_i o58kM')
        description_element = article.find('p')
        if heading_element and description_element:
            heading = heading_element.text.strip()
            description = description_element.text.strip()
            link = article.find('a')
            if link:
                url = base_url + link['href']
            else:
                url = ""
            extracted_data.append({'heading': heading, 'description': description, 'url': url})

    return extracted_data

# Example usage for news websites
websites = [
    {
        'domain': 'News1',
        'url': 'https://timesofindia.indiatimes.com/topic/top-100-in-the-world/news',
        'output_file': 'news1.json'
    },
    {
        'domain': 'News2',
        'url': 'https://timesofindia.indiatimes.com/topic/top-100-in-the-world/news/2',
        'output_file': 'news2.json'
    }
]

for website in websites:
    domain = website['domain']
    url = website['url']
    output_file = website['output_file']

    # Fetch data from the website
    web_data = fetch_data(url)

    if web_data:
        # Parse the fetched data
        parsed_data = BeautifulSoup(web_data, 'html.parser')

        # Extract relevant information from parsed_data
        extracted_data = extract_news_data(parsed_data, url)

        # Store the extracted data in a JSON file
        store_data_json(extracted_data, output_file)
        print(f"Data extracted from {domain} and saved in {output_file}")
    else:
        print(f"Failed to fetch data from {domain}")






# import requests
# from bs4 import BeautifulSoup
# import json
# import csv

# # Fetch data from a website using web scraping
# def fetch_data(url):
#     response = requests.get(url)
#     if response.status_code == 200:
#         return response.content
#     else:
#         return None

# # Store the fetched data in a JSON file
# def store_data_json(data, file_path):
#     with open(file_path, 'w') as file:
#         json.dump(data, file, indent=4)

# # Store the fetched data in a CSV file
# def store_data_csv(data, file_path):
#     with open(file_path, 'w', newline='', encoding='utf-8') as file:
#         writer = csv.writer(file)
#         writer.writerows(data)

# # Extract relevant information from a news website
# def extract_news_data(parsed_data):
#     title_element = parsed_data.find_all('h3')
#     description_element = parsed_data.find_all('p', class_='gs-c-promo-summary gel-long-primer gs-u-mt nw-c-promo-summary')

#     title = title_element.text.strip() if title_element else ""
#     description = description_element.text.strip() if description_element else ""

#     return {'title': title, 'description': description}

# # Example usage for news websites
# websites = [
#     {
#         'domain': 'BBC News',
#         'url': 'https://www.bbc.com/news',
#         'output_file': 'bbc_news_data.json'
#     },
#     {
#         'domain': 'CNN',
#         'url': 'https://www.cnn.com/',
#         'output_file': 'cnn_news_data.json'
#     },
#     {
#         'domain': 'The New York Times',
#         'url': 'https://www.nytimes.com/',
#         'output_file': 'nytimes_news_data.json'
#     }
# ]

# for website in websites:
#     domain = website['domain']
#     url = website['url']
#     output_file = website['output_file']

#     # Fetch data from the website
#     web_data = fetch_data(url)

#     if web_data:
#         # Parse the fetched data
#         parsed_data = BeautifulSoup(web_data, 'html.parser')

#         # Extract relevant information from parsed_data
#         extracted_data = extract_news_data(parsed_data)

#         # Store the extracted data in a JSON file
#         store_data_json(extracted_data, output_file)
#         print(f"Data extracted from {domain} and saved in {output_file}")
#     else:
#         print(f"Failed to fetch data from {domain}")
