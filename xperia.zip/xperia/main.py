# IMPORTS
import os
import re
import sys

from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
import query_lib
import apiFile
import data_update

# WEB ENGINE( pip install PyQtWebEngine)
from PyQt5.QtWebEngineWidgets import *


class SearchSystemWidget(QWidget):
    Hurl="HomePage"
    def __init__(self,url=Hurl):
        super().__init__()
        self.initUI()
        self.url=url

    def initUI(self):
        # Create UI elements
        self.queryLabel = QLabel("Enter query:")
        self.queryInput = QLineEdit()
        self.searchButton = QPushButton("Search")
        self.resultsDisplay = QTextBrowser()
        self.resultLabel = QLabel("AI generated response")
        self.resultsDisplay2 = QTextBrowser()
        self.queryInput.returnPressed.connect(self.search)


        queryLayout = QVBoxLayout()
        queryLayout.addWidget(self.queryLabel)
        queryLayout.addWidget(self.queryInput)
        queryLayout.addWidget(self.searchButton)

        resultLayout = QGridLayout()
        resultLayout.addWidget(self.resultsDisplay,0,0,2,3)
        resultLayout.addWidget(self.resultLabel,0,3,1,2)
        resultLayout.addWidget(self.resultsDisplay2,1,3,1,2)
        queryLayout.addLayout(resultLayout)

        self.setLayout(queryLayout)

        # # Set up layout
        # outerlayout = QVBoxLayout()
        # innerlayout = QHBoxLayout()
        # outerlayout.addWidget(self.queryLabel)
        # outerlayout.addWidget(self.queryInput)
        # outerlayout.addWidget(self.searchButton)
        # innerlayout.addWidget(self.resultsDisplay)
        # innerlayout.addWidget(self.resultsDisplay2)
        # outerlayout.addLayout(innerlayout)
        # self.setLayout(outerlayout)

        # Connect signals and slots
        self.searchButton.clicked.connect(self.search)
        self.resultsDisplay.anchorClicked.connect(self.handle_anchor_click)

    def search(self):
        query = self.queryInput.text()
        # Perform search and display results
        results = perform_search(query)
        results2=perform_ai_search(query)
        self.display_results(results)
        self.display_result2(results2)


    def search_thorugh_nav(self,query):
        # Perform search and display results
        results = perform_search(query)
        results2=perform_ai_search(query)
        self.display_results(results)
        self.display_result2(results2)
    
    def display_result2(self, output):
        self.resultsDisplay2.clear()
        self.resultsDisplay2.append(output)

    def display_results(self, results):
        self.resultsDisplay.clear()
        for result in results:
            heading = result['heading']
            url = result['url']
            relevance = result['relevance']
            self.resultsDisplay.append(f"{heading}")
            self.resultsDisplay.append(f"<a href=\"{url}\">{url}</a>")
            self.resultsDisplay.append(f"Relevance Score: {relevance}")
            self.resultsDisplay.append('')

    def handle_anchor_click(self, url):
        temp_url=QUrl(url.toString())
        self.url=QUrl(url.toString())
        window.add_new_tab(qurl=temp_url)

        print("anchor clicked..",url.toString())
        # Open clicked link in a new tab
        # webTabWidget = WebTabWidget(url.toString())
        # tabWidget=QTabWidget()
        # tabWidget.addTab(webTabWidget, url.toString())
        # tabWidget.setCurrentWidget(webTabWidget)

# # Custom widget for displaying web content in a new tab
# class WebTabWidget(QWidget):
#     def __init__(self, url):
#         super().__init__()
#         self.initUI(url)

#     def initUI(self, url):
#         # Create a QWebEngineView to display the web content
#         self.webView = QWebEngineView()
#         self.webView.load(QUrl(url))

#         # Set up layout
#         layout = QVBoxLayout()
#         layout.addWidget(self.webView)
#         self.setLayout(layout)

# Function to perform search based on query
def perform_ai_search(query):
    return apiFile.main(query)

def perform_search(query):
    # Perform search logic here and return the results as a list of dictionaries
    # Each dictionary should contain 'heading', 'url', and 'relevance' keys
    # with the corresponding values
    results=query_lib.main(query)
    data_update.add_query(query)
    # results = [
    #     {'heading': 'Example Heading 1', 'url': 'http://example.com/1', 'relevance': 0.8},
    #     {'heading': 'Example Heading 2', 'url': 'http://example.com/2', 'relevance': 0.6},
    #     {'heading': 'Example Heading 3', 'url': 'http://example.com/3', 'relevance': 0.9}
    # ]

    return results



# MAIN WINDOW
class MainWindow(QMainWindow):
    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)

        # ADD WINDOW ELEMENTS
        # ADD TAB WIGDETS TO DISPLAY WEB TABS
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setTabsClosable(True)
        self.setCentralWidget(self.tabs)

        # ADD DOUBLE CLICK EVENT LISTENER
        self.tabs.tabBarDoubleClicked.connect(self.tab_open_doubleclick)
        # ADD TAB CLOSE EVENT LISTENER
        self.tabs.tabCloseRequested.connect(self.close_current_tab)
        # ADD ACTIVE TAB CHANGE EVENT LISTENER
        self.tabs.currentChanged.connect(self.current_tab_changed)


        # ADD NAVIGATION TOOLBAR
        navtb = QToolBar("Navigation")
        navtb.setIconSize(QSize(16, 16))
        self.addToolBar(navtb)

        # ADD BUTTONS TO NAVIGATION TOOLBAR
        # PREVIOUS WEB PAGE BUTTON
        back_btn = QAction(QIcon(os.path.join('icons', 'cil-arrow-circle-left.png')), "Back", self)
        back_btn.setStatusTip("Back to previous page")
        navtb.addAction(back_btn)
        # NAVIGATE TO PREVIOUS PAGE
        back_btn.triggered.connect(self.backFunc)




        # NEXT WEB PAGE BUTTON
        next_btn = QAction(QIcon(os.path.join('icons', 'cil-arrow-circle-right.png')), "Forward", self)
        next_btn.setStatusTip("Forward to next page")
        navtb.addAction(next_btn)
        # NAVIGATE TO NEXT WEB PAGE
        next_btn.triggered.connect(self.forwardFunc)


        # REFRESH WEB PAGE BUTTON
        reload_btn = QAction(QIcon(os.path.join('icons', 'cil-reload.png')), "Reload", self)
        reload_btn.setStatusTip("Reload page")
        navtb.addAction(reload_btn)
        # RELOAD WEB PAGE
        reload_btn.triggered.connect(self.reloadFunc)



        # HOME PAGE BUTTON
        home_btn = QAction(QIcon(os.path.join('icons', 'cil-home.png')), "Home", self)
        home_btn.setStatusTip("Go home")
        navtb.addAction(home_btn)
        # NAVIGATE TO DEFAULT HOME PAGE
        home_btn.triggered.connect(self.navigate_home)



        # ADD SEPARATOR TO NAVIGATION BUTTONS
        navtb.addSeparator()


        # ADD LABEL ICON TO SHOW THE SECURITY STATUS OF THE LOADED URL
        self.httpsicon = QLabel()  
        self.httpsicon.setPixmap(QPixmap(os.path.join('icons', 'cil-lock-unlocked.png')))
        navtb.addWidget(self.httpsicon)

        # ADD LINE EDIT TO SHOW AND EDIT URLS
        self.urlbar = QLineEdit()
        navtb.addWidget(self.urlbar)
        # LOAD URL WHEN ENTER BUTTON IS PRESSED

        self.urlbar.returnPressed.connect(self.navigate_to_url)





        # ADD STOP BUTTON TO STOP URL LOADING
        stop_btn = QAction(QIcon(os.path.join('icons', 'cil-media-stop.png')), "Stop", self)
        stop_btn.setStatusTip("Stop loading current page")
        navtb.addAction(stop_btn)
        # STOP URL LOADING
        stop_btn.triggered.connect(lambda: self.tabs.currentWidget().stop())


        # ADD TOP MENU
        # File menu
        file_menu = self.menuBar().addMenu("&File")
        # ADD FILE MENU ACTIONS
        new_tab_action = QAction(QIcon(os.path.join('icons', 'cil-library-add.png')), "New Tab", self)
        new_tab_action.setStatusTip("Open a new tab")
        file_menu.addAction(new_tab_action)
        # ADD NEW TAB
        new_tab_action.triggered.connect(lambda _: self.add_new_tab())

        # Update Dataset Action
        datset_update = QAction(QIcon(os.path.join('icons', 'cil-library-add.png')), "Update Dataset", self)
        datset_update.setStatusTip("Update Dataset")
        file_menu.addAction(datset_update)
        # ADD NEW TAB
        datset_update.triggered.connect(data_update.update)


        # Help menu
        help_menu = self.menuBar().addMenu("&Help")
        # ADD HELP MENU ACTIONS
        ##########################
        navigate_home_action = QAction(QIcon(os.path.join('icons', 'cil-exit-to-app.png')),
                                            "Homepage", self)
        navigate_home_action.setStatusTip("Go to developers Homepage")
        help_menu.addAction(navigate_home_action)
        # NAVIGATE TO DEVELOPER WEBSITE
        # navigate_home_action.triggered.connect(self.navigate_home)



        # SET WINDOW TITTLE AND ICON
        self.setWindowTitle("Xperia")
        self.setWindowIcon(QIcon(os.path.join('icons', 'cil-screen-desktop.png')))


        # ADD STYLESHEET TO CUSTOMIZE YOUR WINDOWS
        # STYLESHEET (DARK MODE)
        self.setStyleSheet("""QWidget{
           background-color: rgb(48, 48, 48);
           color: rgb(255, 255, 255);
        }
        QTabWidget::pane { /* The tab widget frame */
            border-top: 2px solid rgb(90, 90, 90);
            position: absolute;
            top: -0.5em;
            color: rgb(255, 255, 255);
            padding: 5px;
        }

        QTabWidget::tab-bar {
            alignment: left;
        }

        /* Style the tab using the tab sub-control. Note that
            it reads QTabBar _not_ QTabWidget */
        QLabel, QToolButton, QTabBar::tab {
            text-align: center;
            background: rgb(90, 90, 90);
            border: 2px solid rgb(90, 90, 90);
            /*border-bottom-color: #C2C7CB; /* same as the pane color */
            border-radius: 10px;
            min-width: 8ex;
            padding: 5px;
            margin-right: 2px;
            color: rgb(255, 255, 255);
            
            
        }
        QLabel, QToolButton{
        font-family: "Lucida Handwriting";
        }
        QTextBrowser{
            background-color: rgb(0, 36, 36);
            border: 2px solid rgb(90, 90, 90);
            /*border-bottom-color: #C2C7CB; /* same as the pane color */
            border-radius: 10px;
            min-width: 8ex;
            padding: 5px;
            margin-right: 2px;
            color: white;
            font-family: "Lucida Console";   
            font-size: 20px;         
        }
        .a{
            font-family: "Times New Roman";
            font-size: 15px;
            color: blue;
        }

        QLabel:hover, QToolButton::hover, QTabBar::tab:selected, QTabBar::tab:hover {
            background: rgb(49, 49, 49);
            border: 2px solid rgb(0, 36, 36);
            background-color: rgb(0, 36, 36);
        }

        QLineEdit {
            border: 2px solid rgb(0, 36, 36);
            border-radius: 10px;
            padding: 5px;
            background-color: rgb(0, 36, 36);
            color: rgb(255, 255, 255);
        }
        QLineEdit:hover {
            border: 2px solid rgb(0, 66, 124);
        }
        QLineEdit:focus{
            border: 2px solid rgb(0, 136, 255);
            color: rgb(200, 200, 200);
        }
        QPushButton{
            background: rgb(49, 49, 49);
            border: 2px solid rgb(0, 36, 36);
            background-color: rgb(0, 36, 36);
            padding: 5px;
            border-radius: 10px;
            font-family: "Lucida Handwriting";
            
        }""")



        # LOAD DEFAULT HOME PAGE (GOOLE.COM)
        #url = http://www.google.com,
        #label = Homepage
        # self.add_new_tab(QUrl('http://www.google.com'), 'Homepage')


        # Create the search system tab
        self.add_new_tab()
        # self.searchSystemWidget = SearchSystemWidget()
        # self.tabs.addTab(self.searchSystemWidget, "Search System")


        # MainWindow.setLayout(layout)
        # SHOW MAIN WINDOW
        self.show()




    # /////////////////////////////////////////////////////////////////////////
    # /////////////////////////////////////////////////////////////////////////

    # ############################################
    # FUNCTIONS
    ##############################################
    # ADD NEW WEB TAB
    def add_new_tab(self, qurl=None, label="Blank"):
        # p = re.compile("((http|https)://)(www.)?" +
        #      "[a-zA-Z0-9@:%._\\+~#?&//=]" +
        #      "{2,256}\\.[a-z]" +
        #      "{2,6}\\b([-a-zA-Z0-9@:%" +
        #      "._\\+~#?&//=]*)")
        # m = re.search(p,qurl)
        # if not m:
        #     qurl = "https://www.google.com.tr/search?q={}".format(qurl)

        # Check if url value is blank
        if qurl is None:
            self.searchSystemWidget = SearchSystemWidget()
            self.tabs.addTab(self.searchSystemWidget, "Xperia")
            self.tabs.setCurrentWidget(self.searchSystemWidget)
            self.update_urlbar(QUrl("HomePage"))
        else:

            # Load the passed url
            browser = QWebEngineView()
            browser.setUrl(qurl)

            # ADD THE WEB PAGE TAB
            i = self.tabs.addTab(browser, label)
            self.tabs.setCurrentIndex(i)

            # ADD BROWSER EVENT LISTENERS
            # On URL change
            browser.urlChanged.connect(lambda qurl, browser=browser:
                                    self.update_urlbar(qurl, browser))
            # On loadfinished
            browser.loadFinished.connect(lambda _, i=i, browser=browser:
                                        self.tabs.setTabText(i, browser.page().title()[:30]))


    # ADD NEW TAB ON DOUBLE CLICK ON TABS
    def tab_open_doubleclick(self, i):
        if i == -1:  # No tab under the click
            self.add_new_tab()

    # CLOSE TABS 
    def close_current_tab(self, i):
        if self.tabs.count() < 2: #Only close if there is more than one tab open
            return

        self.tabs.removeTab(i)


    # UPDATE URL TEXT WHEN ACTIVE TAB IS CHANGED
    def update_urlbar(self, q, browser=None):
        #q = QURL
        if browser != self.tabs.currentWidget():
            # If this signal is not from the current tab, ignore
            return
        # URL Schema
        try:
            if q.scheme() == 'https':
                # If schema is https change icon to locked padlock to show that the webpage is secure
                self.httpsicon.setPixmap(QPixmap(os.path.join('icons', 'cil-lock-locked.png')))

            else:
                # If schema is not https change icon to locked padlock to show that the webpage is unsecure
                self.httpsicon.setPixmap(QPixmap(os.path.join('icons', 'cil-lock-unlocked.png')))
            self.urlbar.setText(q.toString())
        except:
            self.urlbar.setText(q)
        self.urlbar.setCursorPosition(0)



    # ACTIVE TAB CHANGE ACTIONS
    def current_tab_changed(self):
        # print(type())
        # i = tab index
        # GET CURRENT TAB URL
                    
        # self.searchSystemWidget.search()
        try:
            qurl = QUrl(self.tabs.currentWidget().url())
            self.update_urlbar(qurl, self.tabs.currentWidget())
        except:
            qurl = QUrl(self.searchSystemWidget.queryInput.text())
            if self.searchSystemWidget.queryInput.text() != "":
                self.update_urlbar(f"Most Recent Search: {self.searchSystemWidget.queryInput.text()}", self.searchSystemWidget)
        # self.searchSystemWidget.search()
        # UPDATE URL TEXT
        
    #     # UPDATE WINDOWS TITTLE
    #     self.update_title(self.tabs.currentWidget())


    # # UPDATE WINDOWS TITTLE
    # def update_title(self, browser):
    #     if browser != self.tabs.currentWidget():
    #         # If this signal is not from the current ACTIVE tab, ignore
    #         return
    #     if self.tabs.currentWidget() !=self.searchSystemWidget:
    #         title = self.tabs.currentWidget().page().title()
    #         self.setWindowTitle(title)


    # NAVIGATE TO PASSED URL
    def navigate_to_url(self):  # Does not receive the Url
        # GET URL TEXT
        q = self.urlbar.text()
        p = re.compile("[a-zA-Z0-9@:%._\\+~#?&//=]" +
             "{2,256}\\.[a-z]" +
             "{2,6}\\b([-a-zA-Z0-9@:%" +
             "._\\+~#?&//=]*)")
        m = re.search(p,q)
        if not m:
            if self.tabs.currentWidget() == self.searchSystemWidget:
                self.searchSystemWidget.queryInput.setText(q)
                self.searchSystemWidget.search_thorugh_nav(q)
            else:
                self.searchSystemWidget=SearchSystemWidget()
                self.tabs.addTab(self.searchSystemWidget, q)
                self.tabs.setCurrentWidget(self.searchSystemWidget)
                self.searchSystemWidget.queryInput.setText(q)
                self.searchSystemWidget.search_thorugh_nav(q)
            
            # q = QUrl("https://www.google.com.tr/search?q={}".format(q))

        else:
            q = QUrl(q)
       
            if q.scheme() == "":
                # pass http as default url schema
                q.setScheme("http")
            if self.tabs.currentWidget() == self.searchSystemWidget:
                self.add_new_tab(q)
            else:
                self.tabs.currentWidget().setUrl(q)


    # # NAVIGATE TO DEFAULT HOME PAGE
    def navigate_home(self):
        self.tabs.currentWidget().setUrl(QUrl("https://priyanshu117001.github.io/Resume/"))

    def backFunc(self):
        try:
            if self.tabs.currentWidget() == self.searchSystemWidget:
                pass
            else:
                self.tabs.currentWidget().back()
        except:
            pass
    def forwardFunc(self):
        try:
            if self.tabs.currentWidget() == self.searchSystemWidget:
                pass
            else:
                self.tabs.currentWidget().forward()
        except:
            pass
    def reloadFunc(self):
        try:
            if self.tabs.currentWidget() == self.searchSystemWidget:
                pass
            else:
                self.tabs.currentWidget().reload()
        except:
            pass







app = QApplication(sys.argv)
# APPLICATION NAME
app.setApplicationName("Xperia")
# APPLICATION COMPANY NAME
app.setOrganizationName("Xperia")
# APPLICATION COMPANY ORGANISATION
app.setOrganizationDomain("Xperia.org")


window = MainWindow()
app.exec_()