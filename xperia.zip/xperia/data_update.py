import requests
import urllib.parse
import json
import os
import xmltodict


    # Set up API endpoint and parameters
def wiki(query_input):
    endpoint = "https://en.wikipedia.org/w/api.php"
    params = {
        "action": "query",
        "format": "json",
        "list": "search",
        "srsearch": query_input,
        "exintro": "",
        "explaintext": "",
        "exchars": 300,  # Number of characters for the description
    }
    if "scholar:" in query_input:
        return

    # Make the API request
    response = requests.get(endpoint, params=params)
    data = response.json()

    # Process the response data
    output = []
    if "query" in data and "search" in data["query"]:
        articles = data["query"]["search"]

        # Load existing data if the file exists
        if os.path.exists("output.json"):
            with open("output.json", "r") as f:
                output = json.load(f)

        existing_headings = set(article["heading"] for article in output)

        for article in articles:
            heading = article["title"]
            description = article["snippet"]
            pageid = article["pageid"]

            if heading not in existing_headings:
                # Construct the URL of the article
                url = f"https://en.wikipedia.org/wiki/{urllib.parse.quote(heading)}"

                # Create a dictionary for each new article
                article_data = {
                    "heading": heading,
                    "description": description,
                    "url": url
                }

                output.append(article_data)

    # Save the output to a JSON file
    with open("wiki.json", "w") as f:
        json.dump(output, f, indent=4)


# def reddit(query_input):
#     # Check if the Reddit JSON file exists
#     if os.path.exists("reddit_output.json"):
#         # Load existing Reddit data from the JSON file
#         with open("reddit_output.json", "r") as reddit_file:
#             existing_reddit_data = json.load(reddit_file)
#     else:
#         existing_reddit_data = {}

#     # Reddit API
#     reddit_params = {
#         "q": query_input,
#         "sort": "relevance",
#         "limit": 5
#     }

#     if "scholar:" in query_input:
#         return

#     reddit_response = requests.get("https://www.reddit.com/search.json", params=reddit_params, headers={"User-Agent": "Mozilla/5.0"})
#     reddit_data = reddit_response.json()

#     # Merge the new data with the existing data based on unique post titles
#     merged_reddit_data = existing_reddit_data.copy()
#     for post in reddit_data["data"]["children"]:
#         title = post["data"]["title"]
#         if title not in merged_reddit_data:
#             description = post["data"]["selftext"]  # Extract the post's self-text as the description
#             url = f"https://www.reddit.com{post['data']['permalink']}"  # Complete Reddit URL
#             merged_reddit_data[title] = {
#                 "heading": title,
#                 "description": description,
#                 "url": url
#             }

#     # Save the merged data to the JSON file
#     with open("reddit.json", "w") as reddit_file:
#         json.dump(merged_reddit_data, reddit_file, indent=4)

   
def news(query_input):
# Set your News API key
    api_key = "6d2b98baad0e4426aec7a3d78f6930dd"

    # Set the search query
    search_query = query_input

    # Set the API endpoint and parameters
    endpoint = "https://newsapi.org/v2/everything"
    params = {
        "q": search_query,
        "apiKey": api_key,
        "pageSize": 5
    }

    try:
        # Make the API request
        response = requests.get(endpoint, params=params)
        response.raise_for_status()  # Raise an exception if the response status code indicates an error

        # Process the response data
        output = []
        data = response.json()

        if "articles" in data:
            articles = data["articles"]

            # Load existing data if the file exists
            if os.path.exists("news.json"):
                with open("news.json", "r") as f:
                    output = json.load(f)

            existing_titles = set(article["heading"] for article in output)

            for article in articles:
                heading = article["title"]
                description = article["description"]
                url = article["url"]

                if heading not in existing_titles:
                    # Create a dictionary for each new article
                    article_data = {
                        "heading": heading,
                        "description": description,
                        "url": url
                    }

                    output.append(article_data)

            # Save the output to a JSON file
            with open("news.json", "w") as f:
                json.dump(output, f, indent=4)

            print("Data saved to articles.json")
        else:
            print("No articles found in the API response")
    except requests.exceptions.RequestException as e:
        print("Error occurred while making the API request:", str(e))


# def academic_paper(query_input):
        
#     # Check if the academic papers JSON file exists
#     if os.path.exists("academic_papers.json"):
#         # Load existing academic papers data from the JSON file
#         with open("academic_papers.json", "r") as papers_file:
#             existing_papers_data = json.load(papers_file)
#     else:
#         existing_papers_data = {}

#     # Set the search query
#     search_query = query_input

#     # Set the page size based on the presence of "scholar:" in the query
#     if "scholar:" in search_query:
#         page_size = 10
#     else:
#         page_size = 0
#         return

#     # Set the search query parameters
#     query_params = {
#         "search_query": search_query,
#         "max_results": page_size
#     }

#     try:
#         # Make a GET request to the arXiv API
#         response = requests.get("http://export.arxiv.org/api/query", params=query_params)
#         response.raise_for_status()  # Raise an exception if the response status code indicates an error
#         data = response.text

#         # Process the response
#         papers = data.split("<entry>")
#         merged_papers_data = existing_papers_data.copy()

#         for paper in papers[1:]:  # Skip the first element as it is not a paper entry
#             title = paper.split("<title>")[1].split("</title>")[0]
#             abstract = paper.split("<summary>")[1].split("</summary>")[0]
#             url = paper.split("<id>")[1].split("</id>")[0]

#             if title not in merged_papers_data:
#                 merged_papers_data = {
#                     "heading": title,
#                     "description": abstract,
#                     "url": url
#                 }

#         # Save merged academic papers data to the JSON file
#         with open("academic_papers.json", "w") as papers_file:
#             json.dump(merged_papers_data, papers_file, indent=4)

#     except requests.exceptions.RequestException as e:
#         pass
def academic_paper(query_input):
    # Set the API endpoint and parameters
    if "scholar:" not in query_input:
        return
    else:
        query_input.lstrip("scholar:")

    endpoint = "http://export.arxiv.org/api/query"
    params = {
        "search_query": query_input,
        "max_results": 10
    }


    try:
        # Make the API request
        response = requests.get(endpoint, params=params)
        response.raise_for_status()  # Raise an exception if the response status code indicates an error

        # Process the response data
        output = []
        if response.text:
            data = response.text

            # Parse the XML response data
            parsed_data = xmltodict.parse(data)
            entries = parsed_data["feed"]["entry"]

            # Load existing data if the file exists
            if os.path.exists("papers.json"):
                with open("papers.json", "r") as f:
                    output = json.load(f)

            existing_headings = set(article["heading"] for article in output)

            for entry in entries:
                heading = entry["title"]
                description = entry.get("summary", "")
                url = entry.get("id", "")

                if heading not in existing_headings:
                    # Create a dictionary for each new paper
                    paper_data = {
                        "heading": heading,
                        "description": description,
                        "url": url
                    }

                    output.append(paper_data)

            # Save the output to a JSON file
            with open("acedemic_papers.json", "w") as f:
                json.dump(output, f, indent=4)

            print("Data saved to papers.json")
        else:
            print("Empty response received")
    except requests.exceptions.RequestException as e:
        print("Error occurred while making the API request:", str(e))


def main(query_input=None):
    if query_input==None:
        return None
    else:
        wiki(query_input)
        # reddit(query_input)
        news(query_input)
        academic_paper(query_input)



def open_json_file(file_name):
    """
    Opens a JSON file and returns the data as a Python list.
    """
    with open(file_name, "r") as file:
        data = json.load(file)
    return data

def add_element_to_json_file(element):
    """
    Adds an element to a JSON file.
    The file is assumed to contain a list.
    """
    file_name = "query_list.json"
    data = open_json_file(file_name)
    data.append(element)
    with open(file_name, "w") as file:
        json.dump(data, file)

def clear_json_file(file_name="query_list.json"):
    """
    Clears the contents of a JSON file.
    """
    with open(file_name, "w") as file:
        file.write("[]")  # Overwrite the file with an empty list representation

def read_json_file_as_list(file_name="query_list.json"):
    """
    Reads a JSON file and returns the data as a list.
    """
    data = open_json_file(file_name)
    if not isinstance(data, list):
        raise ValueError("File does not contain a valid list.")
    return data

def add_query(query):
    add_element_to_json_file(query)
    

def update():
    query_list=read_json_file_as_list()
    for q in query_list:
        main(q)
    print("Dataset Updated!!!")
    clear_json_file()

