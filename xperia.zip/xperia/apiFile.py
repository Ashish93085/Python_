import openai

# Set up your OpenAI API key
# openai.api_key = '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'
openai.api_key = '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'

def generate_response(prompt):
    response = openai.Completion.create(
        engine='text-davinci-003',
        prompt=prompt,
        max_tokens=100,
        n=1,
        stop=None,
        temperature=0.7
    )
    return response.choices[0].text.strip()

# Main program loop
def main(prompt=None):
    if prompt == None:
        return "Please Provide a valid query!!!"
    user_input = prompt

    prompt = f"You: {user_input}\nChatGPT:"

    # Generate response from ChatGPT
    try:
        chatgpt_response = generate_response(prompt)
    except:
        chatgpt_response = "Something Went Wrong!!!"
    # chatgpt_response = "Instagram is a free photo and video sharing app used by millions of people around the world. Instagram allows users to take pictures, edit them, and share them with friends and family. It also allows users to follow other users and view their pictures."

    # Print the generated response
    return (chatgpt_response)
if __name__ == "main":
    main()
