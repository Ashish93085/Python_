import requests
import json
import os
import xmltodict
# Set the search query
query_input = "narendra"


# Check if the JSON file already exists and load existing data if available
existing_reddit_data = {}
if os.path.exists("reddit.json"):
    with open("reddit.json", "r") as reddit_file:
        existing_reddit_data = json.load(reddit_file)

# Set the query parameters for the Reddit API

reddit_params = {
    "q": query_input,
    "sort": "relevance",
    "limit": 5
}

# Make the API request to Reddit
reddit_response = requests.get("https://www.reddit.com/search.json", params=reddit_params, headers={"User-Agent": "Mozilla/5.0"})
reddit_data = reddit_response.json()

# Merge the new data with the existing data based on unique post titles
merged_reddit_data = existing_reddit_data.copy()
for post in reddit_data["data"]["children"]:
    title = post["data"]["title"]
    if title not in merged_reddit_data:
        description = post["data"]["selftext"]  # Extract the post's self-text as the description
        url = f"https://www.reddit.com{post['data']['permalink']}"  # Complete Reddit URL
        merged_reddit_data[title] = {
            "heading": title,
            "description": description,
            "url": url
        }

# Save the merged data to the JSON file
with open("reddit.json", "w") as reddit_file:
    json.dump(merged_reddit_data, reddit_file, indent=4)






















# # Check if the news JSON file exists
# if os.path.exists("news_output.json"):
#     # Load existing news data from the JSON file
#     with open("news_output.json", "r") as news_file:
#         existing_news_data = json.load(news_file)
# else:
#     existing_news_data = {}

# # Set your API key
# api_key = "6d2b98baad0e4426aec7a3d78f6930dd"

# # Set the query parameters
# query_params = {
#     "q": query_input,
#     "language": "en",
#     "pageSize": 5,
#     "apiKey": api_key
# }


# try:
#     # Make a GET request to the News API
#     response = requests.get("https://newsapi.org/v2/everything", params=query_params)
#     response.raise_for_status()  # Raise an exception if the response status code indicates an error
#     data = response.json()

#     # Process the response
#     if data["status"] == "ok":
#         articles = data["articles"]
#         merged_news_data = existing_news_data.copy()

#         for article in articles:
#             title = article["title"]
#             description = article["description"]
#             url = article["url"]

#             if title not in merged_news_data:
#                 merged_news_data[title] = {
#                     "heading": title,
#                     "description": description,
#                     "url": url
#                 }

#         # Save merged news data to the JSON file
#         with open("news.json", "w") as news_file:
#             json.dump(merged_news_data, news_file, indent=4)

# except requests.exceptions.RequestException as e:
#     pass






# # Set the API endpoint and parameters
# endpoint = "http://export.arxiv.org/api/query"
# params = {
#     "search_query": search_query,
#     "max_results": 10
# }

# try:
#     # Make the API request
#     response = requests.get(endpoint, params=params)
#     response.raise_for_status()  # Raise an exception if the response status code indicates an error

#     # Process the response data
#     output = []
#     if response.text:
#         data = response.text

#         # Parse the XML response data
#         parsed_data = xmltodict.parse(data)
#         entries = parsed_data["feed"]["entry"]

#         # Load existing data if the file exists
#         if os.path.exists("papers.json"):
#             with open("papers.json", "r") as f:
#                 output = json.load(f)

#         existing_headings = set(article["heading"] for article in output)

#         for entry in entries:
#             heading = entry["title"]
#             description = entry.get("summary", "")
#             url = entry.get("id", "")

#             if heading not in existing_headings:
#                 # Create a dictionary for each new paper
#                 paper_data = {
#                     "heading": heading,
#                     "description": description,
#                     "url": url
#                 }

#                 output.append(paper_data)

#         # Save the output to a JSON file
#         with open("papers.json", "w") as f:
#             json.dump(output, f, indent=4)

#         print("Data saved to papers.json")
#     else:
#         print("Empty response received")
# except requests.exceptions.RequestException as e:
#     print("Error occurred while making the API request:", str(e))
