import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTextBrowser, QTabWidget
from PyQt5.QtCore import Qt, QUrl
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEnginePage
import query_lib

# Custom widget for the search system tab
class SearchSystemWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        # Create UI elements
        self.queryLabel = QLabel("Enter query:")
        self.queryInput = QLineEdit()
        self.searchButton = QPushButton("Search")
        self.resultsDisplay = QTextBrowser()

        # Set up layout
        layout = QVBoxLayout()
        layout.addWidget(self.queryLabel)
        layout.addWidget(self.queryInput)
        layout.addWidget(self.searchButton)
        layout.addWidget(self.resultsDisplay)
        self.setLayout(layout)

        # Connect signals and slots
        self.searchButton.clicked.connect(self.search)
        self.resultsDisplay.anchorClicked.connect(self.handle_anchor_click)

    def search(self):
        query = self.queryInput.text()
        # Perform search and display results
        results = perform_search(query)
        self.display_results(results)

    def display_results(self, results):
        self.resultsDisplay.clear()
        for result in results:
            heading = result['heading']
            url = result['url']
            relevance = result['relevance']
            self.resultsDisplay.append(f"Heading: {heading}")
            self.resultsDisplay.append(f"<a href=\"{url}\">{url}</a>")
            self.resultsDisplay.append(f"Relevance Score: {relevance}")
            self.resultsDisplay.append('')

    def handle_anchor_click(self, url):
        print("anchor clicked..",url.toString())
        # Open clicked link in a new tab
        webTabWidget = WebTabWidget(url.toString())
        tabWidget=QTabWidget()
        tabWidget.addTab(webTabWidget, url.toString())
        tabWidget.setCurrentWidget(webTabWidget)

# Custom widget for displaying web content in a new tab
class WebTabWidget(QWidget):
    def __init__(self, url):
        super().__init__()
        self.initUI(url)

    def initUI(self, url):
        # Create a QWebEngineView to display the web content
        self.webView = QWebEngineView()
        self.webView.load(QUrl(url))

        # Set up layout
        layout = QVBoxLayout()
        layout.addWidget(self.webView)
        self.setLayout(layout)

# Function to perform search based on query
def perform_search(query):
    # Perform search logic here and return the results as a list of dictionaries
    # Each dictionary should contain 'heading', 'url', and 'relevance' keys
    # with the corresponding values
    results=query_lib.main(query)
    # results = [
    #     {'heading': 'Example Heading 1', 'url': 'http://example.com/1', 'relevance': 0.8},
    #     {'heading': 'Example Heading 2', 'url': 'http://example.com/2', 'relevance': 0.6},
    #     {'heading': 'Example Heading 3', 'url': 'http://example.com/3', 'relevance': 0.9}
    # ]
    return results

def main():
    # Create the application
    app = QApplication(sys.argv)

    # Create the main window and tab widget
    mainWindow = QWidget()
    tabWidget = QTabWidget()

    # Create the search system tab
    searchSystemWidget = SearchSystemWidget()
    tabWidget.addTab(searchSystemWidget, "Search System")

    # Set up the main window layout
    layout = QHBoxLayout()
    layout.addWidget(tabWidget)
    mainWindow.setLayout(layout)

    mainWindow.show()

    # Run the application
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
