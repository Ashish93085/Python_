import requests
from bs4 import BeautifulSoup
import json
import csv

# Fetch data from a website using web scraping
def fetch_data(url):
    response = requests.get(url)
    if response.status_code == 200:
        return response.content
    else:
        return None

# Store the fetched data in a JSON file
def store_data_json(data, file_path):
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)

# Store the fetched data in a CSV file
def store_data_csv(data, file_path):
    with open(file_path, 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerows(data)

# Extract relevant information from a news website
def extract_news_data(parsed_data, base_url):
    articles = parsed_data.find_all('div',class_='MjjYud')
    extracted_data = []

    for article in articles:
        heading_element = article.find('h3')
        description_element = article.find('span')
        if heading_element or description_element:
            heading = heading_element.text.strip()
            description = description_element.text.strip()
            link = article.find('a')
            if link:
                url = base_url + link['href']
            else:
                url = ""
            extracted_data.append({'heading': heading, 'description': description, 'url': url})

    return extracted_data

# Example usage for news websites
websites = [
    {
        'domain': 'News1',
        'url': 'https://www.google.com.tr/search?q=top%2050%20news',
        'output_file': 'testing.json'
    }
]

for website in websites:
    domain = website['domain']
    url = website['url']
    output_file = website['output_file']

    # Fetch data from the website
    web_data = fetch_data(url)

    if web_data:
        # Parse the fetched data
        parsed_data = BeautifulSoup(web_data, 'html.parser')

        # Extract relevant information from parsed_data
        extracted_data = extract_news_data(parsed_data, url)

        # Store the extracted data in a JSON file
        store_data_json(extracted_data, output_file)
        print(f"Data extracted from {domain} and saved in {output_file}")
    else:
        print(f"Failed to fetch data from {domain}")