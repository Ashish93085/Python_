import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTextEdit, QTabWidget
from PyQt5.QtCore import Qt
import query_lib

# Custom widget for the search system tab
class SearchSystemWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        # Create UI elements
        self.queryLabel = QLabel("Enter query:")
        self.queryInput = QLineEdit()
        self.searchButton = QPushButton("Search")
        self.resultsDisplay = QTextEdit()

        # Set up layout
        layout = QVBoxLayout()
        layout.addWidget(self.queryLabel)
        layout.addWidget(self.queryInput)
        layout.addWidget(self.searchButton)
        layout.addWidget(self.resultsDisplay)
        self.setLayout(layout)

        # Connect signals and slots
        self.searchButton.clicked.connect(self.search)

    def search(self):
        query = self.queryInput.text()
        # Perform search and display results
        results = perform_search(query)
        self.display_results(results)

    def display_results(self, results):
        self.resultsDisplay.clear()
        for result in results:
            heading = result['heading']
            url = result['url']
            relevance = result['relevance']
            self.resultsDisplay.append(f"Heading: {heading}")
            self.resultsDisplay.append(f"URL: {url}")
            self.resultsDisplay.append(f"Relevance Score: {relevance}")
            self.resultsDisplay.append('')

# Function to perform search based on query
def perform_search(query):
    # Perform search logic here and return the results as a list of dictionaries
    # Each dictionary should contain 'heading', 'url', and 'relevance' keys
    # with the corresponding values

    results =query_lib.main(query)
    # results = [
    #     {'heading': 'Example Heading 1', 'url': 'http://example.com/1', 'relevance': 0.8},
    #     {'heading': 'Example Heading 2', 'url': 'http://example.com/2', 'relevance': 0.6},
    #     {'heading': 'Example Heading 3', 'url': 'http://example.com/3', 'relevance': 0.4}
    # ]
    return results

# Main function
def main():
    app = QApplication(sys.argv)

    # Create the main window
    window = QWidget()
    window.setWindowTitle('Search System')

    # Create a tab widget
    tabWidget = QTabWidget()

    # Create the search system tab
    searchSystemWidget = SearchSystemWidget()
    tabWidget.addTab(searchSystemWidget, 'Search System')

    # Set up the layout
    layout = QVBoxLayout()
    layout.addWidget(tabWidget)
    window.setLayout(layout)

    # Show the main window
    window.show()

    # Run the application
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
